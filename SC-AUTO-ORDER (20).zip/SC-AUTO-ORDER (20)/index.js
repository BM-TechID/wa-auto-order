require("./setting.js")
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require("fs");
const speed = require("performance-now");
const moment = require("moment-timezone");
const toMs = require('ms');
const ms = require('parse-ms');
const os = require('os');
const { sizeFormatter } = require('human-readable');
const { exec, execSync } = require("child_process");
const util = require('util');
const crypto = require("crypto");
const axios = require('axios')
const jimp_1 = require('jimp');
const cron = require("node-cron");

const { OrderKuota } = require("./function/orderkuota")
const { getGroupAdmins, runtime, sleep } = require("./function/myfunc");
const { color } = require('./function/console');
const { addResponList, delResponList, isAlreadyResponList, sendResponList, updateResponList, getDataResponList } = require('./function/respon-list');
const { addResponTesti, delResponTesti, isAlreadyResponTesti, updateResponTesti, getDataResponTesti } = require('./function/respon-testi');
const { expiredCheck, getAllSewa } = require("./function/sewa");
const { TelegraPh } = require('./function/uploader');
const { qrisDinamis } = require("./function/dinamis");
global.prefa = ['', '.']

moment.tz.setDefault("Asia/Jakarta").locale("id");

module.exports = async (ronzz, m, mek) => {
  try {
    const { isQuotedMsg, fromMe } = m
    if (fromMe) return
    const tanggal = moment.tz('Asia/Jakarta').format('DD MMMM YYYY')
    const jamwib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    const dt = moment.tz('Asia/Jakarta').format('HH')
    const content = JSON.stringify(mek.message)
    const type = Object.keys(mek.message)[0];
    const from = m.chat
    const chats = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') && m.message.buttonsResponseMessage.selectedButtonId ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') && m.message.listResponseMessage.singleSelectReply.selectedRowId ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') && JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
    const toJSON = j => JSON.stringify(j, null, '\t')
    const prefix = prefa ? /^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi.test(chats) ? chats.match(/^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi)[0] : "" : prefa ?? '#'
    const isGroup = m.isGroup
    const sender = m.isGroup ? (mek.key.participant ? mek.key.participant : mek.participant) : mek.key.remoteJid
    const senderLid = m.isGroup ? (mek.key.participantLid ? mek.key.participantLid : sender) : mek.key.senderLid ? mek.key.senderLid : sender
    const isOwner = [ronzz.user.id, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(sender) ? true : false
    const pushname = m.pushName
    const budy = (typeof m.text == 'string' ? m.text : '')
    const args = chats.trim().split(/ +/).slice(1);
    const q = args.join(" ");
    const command = chats.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
    const botNumber = ronzz.user.id.split(":")[0] + ronzz.user.id.split("@")[1]
    const botLid = ronzz.user.lid ? ronzz.user.lid.split(':')[0] + '@lid' : botNumber
    const groupMetadata = isGroup ? await ronzz.groupMetadata(from) : ''
    const groupName = isGroup ? groupMetadata.subject : ''
    const groupId = isGroup ? groupMetadata.id : ''
    const groupMembers = isGroup ? groupMetadata.participants : ''
    const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
    const isBotGroupAdmins = groupAdmins.includes(botLid)
    const isGroupAdmins = groupAdmins.includes(senderLid)
    const participants = isGroup ? await groupMetadata.participants : ''
    
    const isImage = (m.mtype == 'imageMessage')
    const isQuotedImage = isQuotedMsg ? content.includes('imageMessage') ? true : false : false
    const isVideo = (m.mtype == 'videoMessage')
    const isQuotedVideo = isQuotedMsg ? content.includes('videoMessage') ? true : false : false
    const isSewa = db.data.sewa[from] ? true : false

    function parseMention(text = '') {
      return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
    }
    
    try {
      var ppuser = await ronzz.profilePictureUrl(sender, "image")
    } catch {
      var ppuser = "https://telegra.ph/file/8dcf2bc718248d2dd189b.jpg"
    }

    const reply = (teks, options = {}) => { ronzz.sendMessage(from, { text: teks, ...options }, { quoted: m }) }
    const Reply = (teks) => ronzz.sendMessage(from, {
      headerType: 1,
      image: fs.readFileSync(thumbnail),
      caption: teks,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        mentionedJid: parseMention(teks),
        externalAdReply: {
          title: botName,
          body: `By ${ownerName}`,
          thumbnailUrl: ppuser,
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m })
    
    const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
    const mentionByReply = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || "" : ""
    const mention = typeof (mentionByTag) == 'string' ? [mentionByTag] : mentionByTag
    mention != undefined ? mention.push(mentionByReply) : []

    async function downloadAndSaveMediaMessage(type_file, path_file) {
      if (type_file === 'image') {
        var stream = await downloadContentFromMessage(m.message.imageMessage || m.message.extendedTextMessage?.contextInfo.quotedMessage.imageMessage, 'image')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      }
      else if (type_file === 'video') {
        var stream = await downloadContentFromMessage(m.message.videoMessage || m.message.extendedTextMessage?.contextInfo.quotedMessage.videoMessage, 'video')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      } else if (type_file === 'sticker') {
        var stream = await downloadContentFromMessage(m.message.stickerMessage || m.message.extendedTextMessage?.contextInfo.quotedMessage.stickerMessage, 'sticker')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      } else if (type_file === 'audio') {
        var stream = await downloadContentFromMessage(m.message.audioMessage || m.message.extendedTextMessage?.contextInfo.quotedMessage.audioMessage, 'audio')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      }
    }

    async function pepe(media) {
      const jimp = await jimp_1.read(media)
      const min = jimp.getWidth()
      const max = jimp.getHeight()
      const cropped = jimp.crop(0, 0, min, max)
      return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp_1.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp_1.MIME_JPEG)
      }
    }

    function digit() {
      let unik = (Math.floor(Math.random() * 200)).toFixed()
      while (db.data.unik.includes(unik) || unik == undefined) {
        unik = (Math.floor(Math.random() * 200)).toFixed()
      }
      db.data.unik.push(unik)
      return Number(unik)
    }

    const formatp = sizeFormatter({
      std: 'JEDEC',
      decimalPlaces: 2,
      keepTrailingZeroes: false,
      render: (literal, symbol) => `${literal} ${symbol}B`,
    })

    //Ucapan waktu
    if (dt >= 0) {
      var ucapanWaktu = ('Selamat Malam🌃')
    }
    if (dt >= 4) {
      var ucapanWaktu = ('Selamat Pagi🌄')
    }
    if (dt >= 12) {
      var ucapanWaktu = ('Selamat Siang☀️')
    }
    if (dt >= 16) {
      var ucapanWaktu = ('️ Selamat Sore🌇')
    }
    if (dt >= 23) {
      var ucapanWaktu = ('Selamat Malam🌙')
    }
    
    if (!db.data.orkut) db.data.orkut = {
      username: "",
      authToken: ""
    }
    if (!db.data.unik || db.data.unik.length >= 199) db.data.unik = ['0']
    if (!db.data.setting[botNumber]) db.data.setting[botNumber] = {
      autoread: true,
      autoketik: false,
      anticall: true
    }
    if (isGroup && !db.data.chat[from]) db.data.chat[from] = {
      welcome: false,
      antilink: false,
      antilink2: false,
      sDone: "",
      sProses: ""
    }

    function Styles(text, style = 1) {
      var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
      var yStr = Object.freeze({
        1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
      });
      var replacer = [];
      xStr.map((v, i) => replacer.push({
        original: v,
        convert: yStr[style].split('')[i]
      }));
      var str = text.toLowerCase().split('');
      var output = [];
      str.map(v => {
        const find = replacer.find(x => x.original == v);
        find ? output.push(find.convert) : output.push(v);
      });
      return output.join('');
    }

    function toRupiah(angka) {
      var saldo = '';
      var angkarev = angka.toString().split('').reverse().join('');
      for (var i = 0; i < angkarev.length; i++)
        if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
      return '' + saldo.split('', saldo.length - 1).reverse().join('');
    }

    expiredCheck(ronzz, m, groupId)

    if (isAlreadyResponList(chats.toLowerCase())) {
      let get_data_respon = getDataResponList(chats.toLowerCase())
      if (get_data_respon.isImage === false) {
        ronzz.sendMessage(from, { text: get_data_respon.response }, {
          quoted: m
        })
      } else {
        ronzz.sendMessage(from, {
          image: {
            url: get_data_respon.image_url
          },
          caption: get_data_respon.response
        }, {
          quoted: m
        })
      }
    }

    if (isAlreadyResponTesti(chats.toLowerCase())) {
      var get_data_respon = getDataResponTesti(chats.toLowerCase())
      ronzz.sendMessage(from, { image: { url: get_data_respon.image_url }, caption: get_data_respon.response }, { quoted: m })
    }

    if (isGroup && db.data.chat[from].antilink) {
      let gc = await ronzz.groupInviteCode(from)
      if (chats.match(/(`https:\/\/chat.whatsapp.com\/${gc}`)/gi)) {
        if (!isBotGroupAdmins) return
        reply(`*GROUP LINK DETECTOR*\n\nAnda tidak akan dikick oleh bot, karena yang anda kirim adalah link group ini.`)
      } else if ((chats.match("http://") || chats.match("https://")) && !chats.match(`https://chat.whatsapp.com/${gc}`)) {
        if (!isBotGroupAdmins) return
        if (!isOwner && !isGroupAdmins) {
          await ronzz.sendMessage(from, { delete: m.key })
          ronzz.sendMessage(from, { text: `*GROUP LINK DETECTOR*\n\nMaaf @${sender.split('@')[0]}, sepertinya kamu mengirimkan link, maaf kamu akan di kick.`, mentions: [sender] })
          await sleep(500)
          ronzz.groupParticipantsUpdate(from, [sender], "remove")
        }
      }
    }

    if (isGroup && db.data.chat[from].antilink2) {
      let gc = await ronzz.groupInviteCode(from)
      if ((chats.match("http://") || chats.match("https://")) && !chats.match(`https://chat.whatsapp.com/${gc}`)) {
        if (!isBotGroupAdmins) return
        if (!isOwner && !isGroupAdmins) {
          await ronzz.sendMessage(from, { delete: m.key })
          ronzz.sendMessage(from, { text: `*GROUP LINK DETECTOR*\n\nMaaf @${sender.split('@')[0]}, sepertinya kamu mengirimkan link, lain kali jangan kirim link yaa.`, mentions: [sender] })
        }
      }
    }

    if (db.data.setting[botNumber].autoread) ronzz.readMessages([m.key])
    if (db.data.setting[botNumber].autoketik) ronzz.sendPresenceUpdate('composing', from)
    if (chats) console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(m.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname), isGroup ? 'in ' + color(groupName) : '')

    switch (command) {
      case 'menu': {
        let teks = global.menu(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'allmenu': {
        let teks = global.allmenu(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'groupmenu': case 'grupmenu': {
        let teks = global.groupmenu(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'infobot': {
        let teks = global.infobot(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'ownermenu': {
        let teks = global.ownermenu(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'storemenu': {
        let teks = global.storemenu(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'ordermenu': {
        let teks = global.ordermenu(prefix, sender, pushname)
        Reply(teks)
      }
        break

      case 'stok': case 'stock': {
        if (Object.keys(db.data.produk).length == 0) return reply("Belum ada produk di database")

        let teks = `*╭────〔 PRODUCT LIST📦 〕─* 
*┊・* Cara membeli produk ketik perintah berikut
*┊・* ${prefix}buy kodeproduk jumlah
*┊・* Contoh: ${prefix}buy netflix 2
*┊・* Pastikan kode dan jumlah akun sudah benar
*┊・* Kontak Admin: @${ownerNomer}
*╰┈┈┈┈┈┈┈┈*\n\n`

        Object.keys(db.data.produk).forEach(i => {
          teks += `*╭──〔 ${db.data.produk[i].name} 〕─*
*┊・ 🔐| Kode:* ${db.data.produk[i].id}
*┊・ 🏷️| Harga:* Rp${toRupiah(db.data.produk[i].price)}
*┊・ 📦| Stok Tersedia:* ${db.data.produk[i].stok.length}
*┊・ 🧾| Stok Terjual:* ${db.data.produk[i].terjual}
*┊・ 📝| Desk:* ${db.data.produk[i].desc}
*┊・ ✍️| Ketik:* ${prefix}buy ${db.data.produk[i].id} 1
*╰┈┈┈┈┈┈┈┈*\n\n`
        })

        ronzz.sendMessage(from, { text: teks, mentions: [ownerNomer + "@s.whatsapp.net"] }, { quoted: m })
      }
        break

      case 'addproduk': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[5]) return reply(`Contoh: ${prefix + command} id|namaproduk|deskripsi|snk|harga|profit`)
        if (db.data.produk[data[0]]) return reply(`Produk dengan ID ${data[0]} sudah ada di database`)

        db.data.produk[data[0]] = {
          id: data[0],
          name: data[1],
          desc: data[2],
          snk: data[3],
          price: data[4],
          profit: data[5],
          terjual: 0,
          stok: []
        }

        reply(`Berhasil menambahkan produk *${data[1]}*`)
      }
        break

      case 'delproduk': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} idproduk`)
        if (!db.data.produk[q]) return reply(`Produk dengan ID *${q}* tidak ada di database`)

        delete db.data.produk[q]

        reply(`Berhasil delete produk *${q}*`)
      }
        break
        
      case 'setharga': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk|harga`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada di database`)
        
        db.data.produk[data[0]].price = Number(data[1])
        reply(`Berhasil set harga produk dengan ID *${data[0]}* menjadi Rp${toRupiah(Number(data[1]))}`)
      }
        break
        
      case 'setjudul': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk|namaproduk`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada di database`)
        
        db.data.produk[data[0]].name = data[1]
        reply(`Berhasil set judul produk dengan ID *${data[0]}* menjadi *${data[1]}*`)
      }
        break
        
      case 'setdesk': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk|deskripsi`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada di database`)
        
        db.data.produk[data[0]].desc = data[1]
        reply(`Berhasil set deskripsi produk dengan ID *${data[0]}*`)
      }
        break
        
      case 'setsnk': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk|snk`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada di database`)
        
        db.data.produk[data[0]].snk = data[1]
        reply(`Berhasil set SNK produk dengan ID *${data[0]}*`)
      }
        break
        
      case 'setprofit': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk|profit`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada di database`)
        
        db.data.produk[data[0]].profit = Number(data[1])
        reply(`Berhasil set profit produk dengan ID *${data[0]}*`)
      }
        break
        
      case 'setkode': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idlama|idbaru`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada di database`)
        
        db.data.produk[data[0]].id = data[1]
        db.data.produk[data[1]] = db.data.produk[data[0]]
        reply(`Berhasil set kode produk dengan ID *${data[0]}* menjadi *${data[1]}*`)
        delete db.data.produk[data[0]]
      }
        break

      case 'addstok': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split(",")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk,email1@gmail.com|password1|profil1|pin1|2fa1\nemail2@gmail.com|password2|profil2|pin2|2fa2\n\n*NOTE*\nJika tidak ada Profil, Pin, 2FA, kosongkan saja atau dikasih tanda strip (-)`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada`)

        let dataStok = data[1].split("\n").map(i => i.trim())
        db.data.produk[data[0]].stok.push(...dataStok)

        reply(`Berhasil menambahkan stok sebanyak ${dataStok.length}`)
      }
        break
        
      case 'getstok': {
        if (!isOwner) return reply(mess.owner)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk|jumlah`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada`)
        if (db.data.produk[data[0]].stok.length <= 0) return reply("Tidak dapat get stok dikarenakan stok habis.")
        if (db.data.produk[data[0]].stok.length < Number(data[1])) return reply(`Stok tersedia ${db.data.produk[data[0]].stok.length}, jadi harap jumlah tidak melebihi stok`)
        
        db.data.produk[data[0]].terjual += Number(data[1])
        let dataStok = []
        for (let i = 0; i < data[1]; i++) {
          dataStok.push(db.data.produk[data[0]].stok.shift())
        }
        
        let reffId = crypto.randomBytes(5).toString("hex").toUpperCase()
        let teks = `Tanggal Transaksi: ${tanggal}\n\n----- ACCOUNT DETAIL -----\n`

        dataStok.forEach(i => {
          let dataAkun = i.split("|")
          teks += `• Email: ${dataAkun[0]}\n• Password: ${dataAkun[1]}\n• Profil: ${dataAkun[2] ? dataAkun[2] : "-"}\n• Pin: ${dataAkun[3] ? dataAkun[3] : "-"}\n• 2FA: ${dataAkun[4] ? dataAkun[4] : "-"}\n\n`
        })

        fs.writeFileSync(`./options/TRX-${reffId}.txt`, teks, "utf8")
        ronzz.sendMessage(sender, {
        document: fs.readFileSync(`./options/TRX-${reffId}.txt`),
        mimetype: "text/plain",
        fileName: `TRX-${reffId}.txt`,
        caption: `*───「 ACCOUNT DETAIL 」───*
Silahkan buka file txt yang sudah diberikan

*╭────「 TRANSAKSI DETAIL 」───*
*┊・ 🧾| Reff Id:* ${reffId}
*┊・ 📦| Nama Barang:* ${db.data.produk[data[0]].name}
*┊・ 🏷️️| Harga Barang:* Rp${toRupiah(db.data.produk[data[0]].price)}
*┊・ 🛍️| Jumlah Order:* ${data[1]}
*┊・ 💰| Total Bayar:* Rp${toRupiah(Number(db.data.produk[data[0]].price) * Number(data[1]))}
*┊・ 📅| Tanggal:* ${tanggal}
*┊・ ⏰| Jam:* ${jamwib} WIB
*╰┈┈┈┈┈┈┈┈*

*───「 SNK PRODUK 」───*

${db.data.produk[data[0]].snk}`
        }, { quoted: m })
        
        db.data.transaksi.push({
          id: data[0],
          name: db.data.produk[data[0]].name,
          price: db.data.produk[data[0]].price,
          date: moment.tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"),
          profit: db.data.produk[data[0]].profit,
          jumlah: Number(data[1])
        })
        
        fs.unlinkSync(`./options/TRX-${reffId}.txt`)
      }
        break

      case 'delstok': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} idproduk`)
        if (!db.data.produk[q]) return reply(`Produk dengan ID *${q}* tidak ada`)

        db.data.produk[q].stok = []

        reply(`Berhasil delete stok produk *${q}*`)
      }
        break

      case 'buy': {
        if (db.data.orkut["authToken"] == "") return reply("Server maintenance, silahkan hubungi Owner untuk login ke Order Kuota")
        if (db.data.order[sender] !== undefined) return reply(`Kamu sedang melakukan order, harap tunggu sampai proses selesai. Atau ketik *${prefix}batal* untuk membatalkan pembayaran.`)
        let data = q.split(" ")
        if (!data[1]) return reply(`Contoh: ${prefix + command} idproduk jumlah`)
        if (!db.data.produk[data[0]]) return reply(`Produk dengan ID *${data[0]}* tidak ada`)

        let stok = db.data.produk[data[0]].stok
        if (stok.length <= 0) return reply("Stok habis, silahkan hubungi Owner untuk restok")
        if (stok.length < data[1]) return reply(`Stok tersedia ${stok.length}, jadi harap jumlah tidak melebihi stok`)

        reply("Sedang membuat QR Code...")

        let amount = Number(db.data.produk[data[0]].price) * Number(data[1])
        let fee = digit()
        let totalAmount = Number(amount) + Number(fee)

        let pay = await qrisDinamis(`${totalAmount}`, "./options/sticker/qris.jpg")
        let time = Date.now() + toMs("10m");
        let expirationTime = new Date(time);
        let timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
        let currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
        let expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
        let hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
        let minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
        let formattedTime = `${hours}:${minutes}`

        await sleep(1000)
        let qrLink = await TelegraPh(pay)
        let cap = `*🧾 MENUNGGU PEMBAYARAN 🧾*\n\n*Produk ID:* ${data[0]}\n*Produk Name:* ${db.data.produk[data[0]].name}\n*Harga:* Rp${toRupiah(db.data.produk[data[0]].price)}\n*Jumlah:* ${data[1]}\n*Biaya Admin:* Rp${toRupiah(Number(fee))}\n*Total:* Rp${toRupiah(totalAmount)}\n*Waktu:* ${timeLeft} menit\n\nSilahkan scan Qris di atas sebelum ${formattedTime} untuk melakukan pembayaran. Jika Qris di atas tidak dapat didownload, silahkan klik link berikut: ${qrLink}\n\nJika ingin membatalkan pembayaran ketik *${prefix}batal*`;
        let mess = await ronzz.sendMessage(from, { image: fs.readFileSync(pay), caption: Styles(cap) }, { quoted: m })

        db.data.order[sender] = {
          id: data[0],
          jumlah: data[1],
          from: from,
          key: mess.key
        }

        while (db.data.order[sender] !== undefined) {
          await sleep(10 * 1000)
          if (Date.now() >= time) {
            await ronzz.sendMessage(from, { delete: mess.key })
            reply("Pembayaran dibatalkan karena telah melewati batas expired.")
            delete db.data.order[sender]
          }
          try {
            let orkut = new OrderKuota(db.data.orkut["username"], db.data.orkut["authToken"])
            let response = await orkut.getTransactionQris()
            let result = response.qris_history.results.find(i => i.status == "IN" && Number(i.kredit.replace(/[.]/g, '')) == parseInt(totalAmount)) //db.data.balance !== undefined ? Number(db.data.balance) + Number(totalAmount) == response.account.results.qris_balance : false
              
            if (result !== undefined) {
              await ronzz.sendMessage(from, { delete: mess.key })
              reply("Pembayaran berhasil, data akun akan segera diproses, silahkan tunggu")

              await sleep(500)
              db.data.produk[data[0]].terjual += Number(data[1])
              let dataStok = []
              for (let i = 0; i < data[1]; i++) {
                dataStok.push(db.data.produk[data[0]].stok.shift())
              }

              let reffId = crypto.randomBytes(5).toString("hex").toUpperCase()
              let teks = `Tanggal Transaksi: ${tanggal}\n\n----- ACCOUNT DETAIL -----\n`

              dataStok.forEach(i => {
                let dataAkun = i.split("|")
                teks += `• Email: ${dataAkun[0]}\n• Password: ${dataAkun[1]}\n• Profil: ${dataAkun[2] ? dataAkun[2] : "-"}\n• Pin: ${dataAkun[3] ? dataAkun[3] : "-"}\n• 2FA: ${dataAkun[4] ? dataAkun[4] : "-"}\n\n`
              })

              fs.writeFileSync(`./options/TRX-${reffId}.txt`, teks, "utf8")
              ronzz.sendMessage(sender, {
                document: fs.readFileSync(`./options/TRX-${reffId}.txt`),
                mimetype: "text/plain",
                fileName: `TRX-${reffId}.txt`,
                caption: `*───「 ACCOUNT DETAIL 」───*
Silahkan buka file txt yang sudah diberikan

*╭────「 TRANSAKSI DETAIL 」───*
*┊・ 🧾| Reff Id:* ${reffId}
*┊・ 📦| Nama Barang:* ${db.data.produk[data[0]].name}
*┊・ 🏷️️| Harga Barang:* Rp${toRupiah(db.data.produk[data[0]].price)}
*┊・ 🛍️| Jumlah Order:* ${data[1]}
*┊・ 💰| Total Bayar:* Rp${toRupiah(totalAmount)}
*┊・ 📅| Tanggal:* ${tanggal}
*┊・ ⏰| Jam:* ${jamwib} WIB
*╰┈┈┈┈┈┈┈┈*

*───「 SNK PRODUK 」───*

${db.data.produk[data[0]].snk}`
              }, { quoted: m })
              
              await ronzz.sendMessage(ownerNomer + "@s.whatsapp.net", { text: `Hai Owner,
Ada transaksi yang telah dibayar!

*╭────「 TRANSAKSI DETAIL 」───*
*┊・ 🧾| Reff Id:* ${reffId}
*┊・ 📮| Nomor:* @${sender.split("@")[0]}
*┊・ 📦| Nama Barang:* ${db.data.produk[data[0]].name}
*┊・ 🏷️️| Harga Barang:* Rp${toRupiah(db.data.produk[data[0]].price)}
*┊・ 🛍️| Jumlah Order:* ${data[1]}
*┊・ 💰| Total Bayar:* Rp${toRupiah(totalAmount)}
*┊・ 📅| Tanggal:* ${tanggal}
*┊・ ⏰| Jam:* ${jamwib} WIB
*╰┈┈┈┈┈┈┈┈*`, mentions: [sender] })

              db.data.transaksi.push({
                id: data[0],
                name: db.data.produk[data[0]].name,
                price: db.data.produk[data[0]].price,
                date: moment.tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"),
                profit: db.data.produk[data[0]].profit,
                jumlah: Number(data[1])
              })

              fs.unlinkSync(`./options/TRX-${reffId}.txt`)
              delete db.data.order[sender]
            } /*else {
              db.data.balance = response.account.results.qris_balance
            }*/
          } catch (error) {
            reply("Pesanan dibatalkan!")
            console.log("Error checking transaction status:", error);
            delete db.data.order[sender]
          }
        }
      }
        break

      case 'batal': {
        if (db.data.order[sender] == undefined) return
        
        await ronzz.sendMessage(db.data.order[sender].from, { delete: db.data.order[sender].key })
        reply("Berhasil membatalkan pembayaran")
        delete db.data.order[sender]
      }
        break
        
      case 'rekap': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh ${prefix + command} mingguan\n\nTipe rekap:\nmingguan\nbulanan`)
        
        function bulankelompok(transaksi) {
          let transaksiHarian = {};

          transaksi.forEach(data => {
            let tanggall = new Date(data.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            if (!transaksiHarian[tanggall]) {
              transaksiHarian[tanggall] = [];
            }
            transaksiHarian[tanggall].push(data);
          });

          return transaksiHarian;
        }
        
        function kelompokkanTransaksi(transaksi) {
          let today = new Date(moment.tz("Asia/Jakarta").format("YYYY-MM-DD"));
          let startOfWeek = new Date(today);
          startOfWeek.setDate(today.getDate() - today.getDay());

          let endOfWeek = new Date(today);
          endOfWeek.setDate(startOfWeek.getDate() + 6);
          endOfWeek.setHours(23);
          endOfWeek.setMinutes(59);

          let transaksiMingguIni = transaksi.filter(data => {
            let transaksiDate = new Date(data.date);
            transaksiDate.setDate(transaksiDate.getDate());
            return transaksiDate >= startOfWeek && transaksiDate <= endOfWeek;
          });

          let transaksiMingguan = {};
          transaksiMingguIni.forEach(data => {
            let tanggall = new Date(data.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            if (!transaksiMingguan[tanggall]) {
              transaksiMingguan[tanggall] = [];
            }
            transaksiMingguan[tanggall].push(data);
          });

          let sortedTransaksiMingguan = {};
          Object.keys(transaksiMingguan).sort((a, b) => {
            let days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            return days.indexOf(a.split(',')[0]) - days.indexOf(b.split(',')[0]);
          }).forEach(key => {
            sortedTransaksiMingguan[key] = transaksiMingguan[key];
          });

          return sortedTransaksiMingguan;
        }
        
        function rekapMingguan(transaksiHarian) {
          let totalStokTerjual = 0;
          let totalPendapatanKotor = 0;
          let totalPendapatanBersih = 0;
          let rekap = "*`Rekap Mingguan:`*\n\n";

          let sortedDates = Object.keys(transaksiHarian).sort((a, b) => {
            let dateA = new Date(a.split(',')[1]);
            let dateB = new Date(b.split(',')[1]);
            return dateA - dateB;
          });

          sortedDates.forEach((tanggall, index) => {
            let dataTransaksi = transaksiHarian[tanggall];
            let stokTerjualHarian = 0;
            let pendapatanKotorHarian = 0;
            let pendapatanBersihHarian = 0;

            dataTransaksi.forEach(data => {
              stokTerjualHarian += parseInt(data.jumlah);
              pendapatanKotorHarian += parseInt(data.price) * parseInt(data.jumlah);
              pendapatanBersihHarian += parseInt(data.profit) * parseInt(data.jumlah);
            });

            totalStokTerjual += stokTerjualHarian;
            totalPendapatanKotor += pendapatanKotorHarian;
            totalPendapatanBersih += pendapatanBersihHarian;
            rekap += `- *Total Stok Terjual:* ${totalStokTerjual}\n`;
            rekap += `- *Total Pendapatan Kotor:* Rp${toRupiah(totalPendapatanKotor)}\n`;
            rekap += `- *Total Pendapatan Bersih:* Rp${toRupiah(totalPendapatanBersih)}\n\n`;

            rekap += `${index + 1}. *\`${new Date(tanggall.split(',')[1] + tanggall.split(',')[2]).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\`*\n`;
            rekap += `- *Stok Terjual:* ${stokTerjualHarian}\n`;
            rekap += `- *Pendapatan Kotor:* Rp${toRupiah(pendapatanKotorHarian)}\n`;
            rekap += `- *Pendapatan Bersih:* Rp${toRupiah(pendapatanBersihHarian)}\n\n`;
          });

          return rekap;
        }
        
        function rekapBulanan(transaksiHarian) {
          let totalStokTerjual = 0;
          let totalPendapatanKotor = 0;
          let totalPendapatanBersih = 0;
          let rekap = "*`Rekap Bulanan:`*\n\n";

          const bulanan = {};

          Object.entries(transaksiHarian).forEach(([tanggall, dataTransaksi]) => {
            let bulan = new Date(tanggall).toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });

            if (!bulanan[bulan]) {
              bulanan[bulan] = {
                stokTerjual: 0,
                pendapatanKotor: 0,
                pendapatanBersih: 0,
                transaksiPerHari: {}
              };
            }

            dataTransaksi.forEach(data => {
              let hari = new Date(data.date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

              if (!bulanan[bulan].transaksiPerHari[hari]) {
                bulanan[bulan].transaksiPerHari[hari] = [];
              }

              bulanan[bulan].transaksiPerHari[hari].push(data);
            });

            dataTransaksi.forEach(data => {
              bulanan[bulan].stokTerjual += parseInt(data.jumlah);
              bulanan[bulan].pendapatanKotor += parseInt(data.price) * parseInt(data.jumlah);
              bulanan[bulan].pendapatanBersih += parseInt(data.profit) * parseInt(data.jumlah);
            });
          });

          Object.entries(bulanan).forEach(([bulan, dataBulan]) => {
            rekap += `\`${bulan}:\`\n`;

            Object.entries(dataBulan.transaksiPerHari).forEach(([hari, transaksiHari]) => {
              let stokTerjualHari = 0;
              let pendapatanKotorHari = 0;
              let pendapatanBersihHari = 0;
              transaksiHari.forEach(transaksi => {
                stokTerjualHari += parseInt(transaksi.jumlah);
                pendapatanKotorHari += parseInt(transaksi.price) * parseInt(transaksi.jumlah);
                pendapatanBersihHari += parseInt(transaksi.profit) * parseInt(transaksi.jumlah);
              });
              rekap += `- *${hari}:*\n`;
              rekap += `  - *Stok Terjual:* ${stokTerjualHari}\n`;
              rekap += `  - *Pendapatan Kotor:* Rp${toRupiah(parseInt(pendapatanKotorHari))}\n`;
              rekap += `  - *Pendapatan Bersih:* Rp${toRupiah(parseInt(pendapatanBersihHari))}\n\n`;
            });

            rekap += `- *Total Stok Terjual:* ${dataBulan.stokTerjual}\n`;
            rekap += `- *Total Pendapatan Kotor:* Rp${toRupiah(dataBulan.pendapatanKotor)}\n`;
            rekap += `- *Total Pendapatan Bersih:* Rp${toRupiah(dataBulan.pendapatanBersih)}\n\n`;

            totalStokTerjual += dataBulan.stokTerjual;
            totalPendapatanKotor += dataBulan.pendapatanKotor;
            totalPendapatanBersih += dataBulan.pendapatanBersih;
          });

          return rekap;
        }
        
        if (q.toLowerCase() == "harian") {
          let harian = kelompokkanTransaksi(db.data.transaksi);
          reply(rekapMingguan(harian))
        } else if (q.toLowerCase() == "mingguan") {
          let mingguan = kelompokkanTransaksi(db.data.transaksi);
          reply(rekapMingguan(mingguan))
        } else if (q.toLowerCase() == "bulanan") {
          let bulanan = bulankelompok(db.data.transaksi);
          reply(rekapBulanan(bulanan))
        } else {
          reply("Tipe rekap tidak valid")
        }
      }
        break
        
      case 'loginorkut': {
        if (!isOwner) return reply(mess.owner)
        if (isGroup) return reply(mess.private)
        let data = q.split("|")
        if (!data[1]) return reply(`Contoh: ${prefix + command} username|password`)
        let orkut = new OrderKuota()
        let response = await orkut.loginRequest(data[0], data[1])
        if (!response.success) return reply(`Login ke OrderKuota gagal!\n\nAlasan: ${response.message}`)
        db.data.orkut["username"] = data[0]
        reply(`OTP berhasil dikirim ke email ${response.results.otp_value}\n\nUntuk memverifikasi OTP silahkan ketik *${prefix}verifotp <otp>*`)
      }
        break
        
      case 'verifotp': {
        if (!isOwner) return reply(mess.owner)
        if (isGroup) return reply(mess.private)
        if (!q) return reply(`Contoh: ${prefix + command} otp`)
        let orkut = new OrderKuota()
        let response = await orkut.getAuthToken(db.data.orkut["username"], q)
        if (!response.success) return reply(`Gagal memverifikasi OTP!\n\nAlasan: ${response.message}`)
        db.data.orkut["authToken"] = response.results.token
        reply(`Login ke OrderKuota sukses!\n\n*────「 DATA AKUN 」────*\n\n*» Name:* ${response.results.name}\n*» Username:* ${response.results.username}\n*» Saldo:* Rp${toRupiah(response.results.balance)}`)
      }
        break

      case 'sticker': case 's': case 'stiker': {
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${tanggal}.jpg`)
          reply(mess.wait)
          ronzz.sendImageAsSticker(from, media, m, { packname: `${packname}`, author: `${author}` })
        } else if (isVideo || isQuotedVideo) {
          let media = await downloadAndSaveMediaMessage('video', `./options/sticker/${tanggal}.mp4`)
          reply(mess.wait)
          ronzz.sendVideoAsSticker(from, media, m, { packname: `${packname}`, author: `${author}` })
        } else {
          reply(`Kirim/reply gambar/vidio dengan caption *${prefix + command}*`)
        }
      }
        break

      case 'addsewa': {
        if (!isOwner) return reply(mess.owner)
        if (!isGroup) return reply(mess.group)
        if (!q) return reply(`Ex: ${prefix + command} hari\n\nContoh: ${prefix + command} 30d`)
        db.data.sewa[from] = {
          id: from,
          expired: Date.now() + toMs(q)
        }
        Reply(`*SEWA ADDED*\n\n*ID*: ${groupId}\n*EXPIRED*: ${ms(toMs(q)).days} days ${ms(toMs(q)).hours} hours ${ms(toMs(q)).minutes} minutes\n\nBot akan keluar secara otomatis dalam waktu yang sudah di tentukan.`)
      }
        break

      case 'delsewa': {
        if (!isOwner) return reply(mess.owner)
        if (!isGroup) return reply(mess.group)
        delete db.data.sewa[from]
        reply('Sukses delete sewa di group ini.')
      }
        break

      case 'ceksewa': {
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isGroup) return reply(mess.group)
        if (!isSewa) return reply('Kamu belum sewa bot.')
        let cekExp = ms(db.data.sewa[from].expired - Date.now())
        Reply(`*SEWA EXPIRED*\n\n*ID*: ${groupId}\n*SEWA EXPIRED*: ${cekExp.days} days ${cekExp.hours} hours ${cekExp.minutes} minutes`)
      }
        break

      case 'listsewa': {
        if (!isOwner) return reply(mess.owner)
        if (db.data.sewa == 0) return reply('Belum ada list sewa di database')
        let teks = '*LIST SEWA BOT*\n\n'
        let sewaKe = 0
        for (let i = 0; i < getAllSewa().length; i++) {
          sewaKe++
          teks += `${sewaKe}. ${getAllSewa()[i]}\n\n`
        }
        Reply(teks)
      }
        break

      case 'kalkulator': {
        if (!q) return reply(`Contoh: ${prefix + command} + 5 6\n\nList kalkulator:\n+\n-\n÷\n×`)
        if (q.split(" ")[0] == "+") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 + q2}`)
        } else if (q.split(" ")[0] == "-") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 - q2}`)
        } else if (q.split(" ")[0] == "÷") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 / q2}`)
        } else if (q.split(" ")[0] == "×") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 * q2}`)
        }
      }
        break

      case 'welcome': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].welcome) return reply('Welcome sudah aktif di grup ini.')
          db.data.chat[from].welcome = true
          reply('Sukses mengaktifkan welcome di grup ini.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].welcome) return reply('Welcome sudah tidak aktif di grup ini.')
          db.data.chat[from].welcome = false
          reply('Sukses menonaktifkan welcome di grup ini.')
        }
      }
        break

      case 'antilink': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].antilink) return reply('Antilink sudah aktif di grup ini.')
          db.data.chat[from].antilink = true
          reply('Sukses mengaktifkan antilink di grup ini.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].antilink) return reply('Antilink sudah tidak aktif di grup ini.')
          db.data.chat[from].antilink = false
          reply('Sukses menonaktifkan antilink di grup ini.')
        }
      }
        break

      case 'antilinkv2': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].antilink2) return reply('Antilinkv2 sudah aktif di grup ini.')
          db.data.chat[from].antilink2 = true
          reply('Sukses mengaktifkan antilinkv2 di grup ini.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].antilink2) return reply('Antilinkv2 sudah tidak aktif di grup ini.')
          db.data.chat[from].antilink2 = false
          reply('Sukses menonaktifkan antilinkv2 di grup ini.')
        }
      }
        break

      case 'anticall': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].anticall) return reply('Anticall sudah aktif.')
          db.data.chat[from].anticall = true
          reply('Sukses mengaktifkan anticall.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].anticall) return reply('Anticall sudah tidak aktif.')
          db.data.chat[from].anticall = false
          reply('Sukses menonaktifkan anticall.')
        }
      }
        break

      case 'kick': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let number;
        if (q.length !== 0) {
          number = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
          ronzz.groupParticipantsUpdate(from, [number], "remove")
            .then(res => reply('Sukses...'))
            .catch((err) => reply(mess.error.api))
        } else if (isQuotedMsg) {
          number = m.quoted.sender
          ronzz.groupParticipantsUpdate(from, [number], "remove")
            .then(res => reply('Sukses...'))
            .catch((err) => reply(mess.error.api))
        } else {
          reply('Tag atau balas pesan orang yang ingin dikeluarkan dari grup.')
        }
      }
        break

      case 'promote': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let number;
        if (q.length !== 0) {
          number = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
          ronzz.groupParticipantsUpdate(from, [number], "promote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai admin`, mentions: [number] }, { quoted: m }))
            .catch((err) => reply(mess.error.api))
        } else if (isQuotedMsg) {
          number = m.quoted.sender
          ronzz.groupParticipantsUpdate(from, [number], "promote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai admin`, mentions: [number] }, { quoted: m }))
            .catch((err) => reply(mess.error.api))
        } else {
          reply('Tag atau balas pesan orang yang ingin dijadikan admin.')
        }
      }
        break

      case 'demote': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let number;
        if (q.length !== 0) {
          number = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
          ronzz.groupParticipantsUpdate(from, [number], "demote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai anggota group`, mentions: [number] }, { quoted: m }))
            .catch((err) => reply(mess.error.api))
        } else if (isQuotedMsg) {
          number = m.quoted.sender
          ronzz.groupParticipantsUpdate(from, [number], "demote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai anggota group`, mentions: [number] }, { quoted: m }))
            .catch((err) => reply(mess.error.api))
        } else {
          reply('Tag atau balas pesan orang yang ingin dijadikan anggota group.')
        }
      }
        break

      case 'revoke':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        await ronzz.groupRevokeInvite(from)
          .then(res => {
            reply('Sukses menyetel tautan undangan grup ini.')
          }).catch(() => reply(mess.error.api))
        break

      case 'linkgrup': case 'linkgroup': case 'linkgc': {
        if (!isGroup) return reply(mess.group)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let url = await ronzz.groupInviteCode(from).catch(() => reply(mess.errorApi))
        url = 'https://chat.whatsapp.com/' + url
        reply(url)
      }
        break

      case 'del': case 'delete': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isQuotedMsg) return reply(`Reply chat yang ingin dihapus dengan caption *${prefix + command}*`)
        if (m.quoted.fromMe) {
          await ronzz.sendMessage(from, { delete: { fromMe: true, id: m.quoted.id, remoteJid: from } })
        } else if (!m.quoted.fromMe) {
          if (!isBotGroupAdmins) return reply(mess.botAdmin)
          await ronzz.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } })
        }
      }
        break

      case 'blok': case 'block':
        if (!isOwner && !fromMe) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 628xxx`)
        await ronzz.updateBlockStatus(q.replace(/[^0-9]/g, '') + '@s.whatsapp.net', "block") // Block user
        reply('Sukses block nomor.')
        break

      case 'unblok': case 'unblock':
        if (!isOwner && !fromMe) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 628xxx`)
        await ronzz.updateBlockStatus(q.replace(/[^0-9]/g, '') + '@s.whatsapp.net', "unblock") // Block user
        reply('Sukses unblock nomor.')
        break


      case 'owner':
        ronzz.sendContact(from, [ownerNomer], m)
        break


      case 'tes': case 'runtime':
        reply(`*STATUS : BOT ONLINE*\n_Runtime : ${runtime(process.uptime())}_`)
        break

      case 'ping':
        let timestamp = speed()
        let latensi = speed() - timestamp
        reply(`Kecepatan respon _${latensi.toFixed(4)} Second_\n\n*💻 INFO SERVER*\nHOSTNAME: ${os.hostname}\nRAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}\nCPUs: ${os.cpus().length} core`)
        break

      case 'setdone':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sDone.length !== 0) return reply(`Set done sudah ada di group ini.`)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sDone = q
        reply(`Sukses set done`)
        break

      case 'deldone':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sDone.length == 0) return reply(`Belum ada set done di sini.`)
        db.data.chat[from].sDone = ""
        reply(`Sukses delete set done`)
        break

      case 'changedone':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sDone = q
        reply(`Sukses mengganti teks set done`)
        break

      case 'setproses':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sProses.length !== 0) return reply(`Set proses sudah ada di group ini.`)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sProses = q
        reply(`Sukses set proses`)
        break

      case 'delproses':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sProses.length == 0) return reply(`Belum ada set proses di sini.`)
        db.data.chat[from].sProses = ""
        reply(`Sukses delete set proses`)
        break

      case 'changeproses':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sProses = q
        reply(`Sukses ganti teks set proses`)
        break

      case 'done': {
        if (!isGroup) return (mess.group)
        if (!isGroupAdmins && !isOwner) return (mess.admin)
        if (q.startsWith("@")) {
          if (db.data.chat[from].sDone.length !== 0) {
            let textDone = db.data.chat[from].sDone
            ronzz.sendMessage(from, { text: textDone.replace('tag', q.replace(/[^0-9]/g, '')).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Berhasil'), mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] });
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Berhasil\`\`\`\n\nTerimakasih @${q.replace(/[^0-9]/g, '')} next order yaa🙏`, mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] }, { quoted: m });
          }
        } else if (isQuotedMsg) {
          if (db.data.chat[from].sDone.length !== 0) {
            let textDone = db.data.chat[from].sDone
            ronzz.sendMessage(from, { text: textDone.replace('tag', m.quoted.sender.split("@")[0]).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Berhasil'), mentions: [m.quoted.sender] }, { quoted: msg })
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Berhasil\`\`\`\n\nTerimakasih @${m.quoted.sender.split("@")[0]} next order yaa🙏`, mentions: [m.quoted.sender] })
          }
        } else {
          reply('Reply atau tag orangnya')
        }
      }
        break

      case 'proses':
        if (!isGroup) return (mess.group)
        if (!isGroupAdmins && !isOwner) return (mess.admin)
        if (isQuotedMsg) {
          if (db.data.chat[from].sProses.length !== 0) {
            let textProses = db.data.chat[from].sProses
            ronzz.sendMessage(from, { text: textProses.replace('tag', m.quoted.sender.split("@")[0]).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Pending'), mentions: [m.quoted.sender] }, { quoted: m });
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Pending\`\`\`\n\nPesanan @${m.quoted.sender.split("@")[0]} sedang diproses🙏`, mentions: [m.quoted.sender] });
          }
        } else if (q.startsWith("@")) {
          if (db.data.chat[from].sProses.length !== 0) {
            let textProses = db.data.chat[from].sProses
            ronzz.sendMessage(from, { text: textProses.replace('tag', q.replace(/[^0-9]/g, '')).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Pending'), mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] });
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Pending\`\`\`\n\nPesanan @${q.replace(/[^0-9]/g, '')} sedang diproses🙏`, mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] }, { quoted: m });
          }
        } else {
          reply('Reply atau tag orangnya')
        }
        break

      case 'list': {
        if (db.data.list.length === 0) return reply(`Belum ada list respon di database`)
        var sortFunc = (a, b) => {
          var textA = a.key.toLowerCase()
          var textB = b.key.toLowerCase()
          if (textA > textB) return 1
          if (textA < textB) return -1
        }
        db.data.list.sort(sortFunc)
        let teks = `Hai @${sender.split("@")[0]}\nBerikut list message di grup ini\n\n*╭────「 LIST MESSAGE 」───*\n`
        for (let x of db.data.list) {
          teks += `*┊ 🛍️ ${x.key.toUpperCase()}*\n`
        }
        teks += `*╰┈┈┈┈┈┈┈┈*`
        ronzz.sendMessage(from, { text: teks, mentions: [sender] }, { quoted: m })
      }
        break

      case 'testi': {
        if (Object.keys(db.data.testi).length === 0) return reply(`Belum ada list testi di database`)
        var sortFunc = (a, b) => {
          var textA = a.key.toLowerCase()
          var textB = b.key.toLowerCase()
          if (textA > textB) return 1
          if (textA < textB) return -1
        }
        db.data.testi.sort(sortFunc)
        let teks = `Hai @${sender.split("@")[0]}\nBerikut list testi Owner saya\n\n*╭────「 LIST TESTI 」───*\n`
        for (let x of db.data.testi) {
          teks += `*┊ 🛍️ ${x.key.toUpperCase()}*\n`
        }
        teks += `*╰┈┈┈┈┈┈┈┈*`
        ronzz.sendMessage(from, { text: teks, mentions: [sender] }, { quoted: m })
      }
        break

      case 'addlist': {
        if (!isOwner) return reply(mess.owner)
        if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
        if (isAlreadyResponList(q.split("@")[0])) return reply(`List respon dengan key : *${q.split("@")[0]}* sudah ada di group ini.`)
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          addResponList(q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil menambah list menu *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          addResponList(q.split("@")[0], q.split("@")[1], false, '-')
          reply(`Berhasil menambah list respon *${q.split("@")[0]}*`)
        }
      }
        break

      case 'addtesti': {
        if (!isOwner) return reply(mess.owner)
        if (isImage || isQuotedImage) {
          if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
          if (isAlreadyResponTesti(q.split("@")[0])) return reply(`List respon dengan key : *${q.split("@")[0]}* sudah ada.`)
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          addResponTesti(q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil menambah list testi *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          reply(`Kirim gambar dengan caption ${prefix + command} *key@response* atau reply gambar yang sudah ada dengan caption ${prefix + command} *key@response*`)
        }
      }
        break

      case 'dellist':
        if (!isOwner) return reply(mess.owner)
        if (db.data.list.length === 0) return reply(`Belum ada list message di database`)
        if (!q) return reply(`Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${prefix + command} hello`)
        if (!isAlreadyResponList(q)) return reply(`List respon dengan key *${q}* tidak ada di database!`)
        delResponList(q)
        reply(`Sukses delete list respon dengan key *${q}*`)
        break

      case 'deltesti':
        if (!isOwner) return reply(mess.owner)
        if (db.data.testi.length === 0) return reply(`Belum ada list testi di database`)
        if (!q) return reply(`Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${prefix + command} hello`)
        if (!isAlreadyResponTesti(q)) return reply(`List testi dengan key *${q}* tidak ada di database!`)
        delResponTesti(q)
        reply(`Sukses delete list testi dengan key *${q}*`)
        break

      case 'setlist': {
        if (!isOwner) return reply(mess.owner)
        if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
        if (!isAlreadyResponList(q.split("@")[0])) return reply(`List respon dengan key *${q.split("@")[0]}* tidak ada di group ini.`)
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          updateResponList(q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil mengganti list menu *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          updateResponList(q.split("@")[0], q.split("@")[1], false, '-')
          reply(`Berhasil mengganti list respon *${q.split("@")[0]}*`)
        }
      }
        break

      case 'settesti': {
        if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
        if (!isAlreadyResponTesti(q.split("@")[0])) return reply(`List testi dengan key *${q.split("@")[0]}* tidak ada di database.`)
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          updateResponTesti(q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil mengganti list testi *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          reply(`Kirim gambar dengan caption ${prefix + command} *key@response* atau reply gambar yang sudah ada dengan caption ${prefix + command} *key@response*`)
        }
      }
        break

      case 'open':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        await ronzz.groupSettingUpdate(from, 'not_announcement')
        await reply(`Sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini.`)
        break

      case 'close':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        await ronzz.groupSettingUpdate(from, 'announcement')
        await reply(`Sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini.`)
        break

      case 'tagall':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        let teks = `══✪〘 *👥 TAG ALL* 〙✪══\n\n${q ? q : 'Tidak ada pesan'}\n`
        for (let mem of participants) {
          teks += `➲ @${mem.id.split('@')[0]}\n`
        }
        ronzz.sendMessage(from, { text: teks, mentions: participants.map(a => a.id) })
        break

      case 'hidetag': case 'ht': case 'h': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        let mem = groupMembers.map(i => i.id)
        ronzz.sendMessage(from, { text: q ? q : '', mentions: mem })
      }
        break

      case 'setdesc':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        if (!q) return reply(`Contoh: ${prefix + command} New Description by ${ownerName}`)
        await ronzz.groupUpdateDescription(from, q)
          .then(res => {
            reply(`Sukses set deskripsi group.`)
          }).catch(() => reply(mess.error.api))
        break

      case 'setppgrup': case 'setppgc':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        if (isImage || isQuotedImage) {
          var media = await downloadAndSaveMediaMessage('image', `ppgc${from}.jpeg`)
          try {
            let { img } = await pepe(media)
            await ronzz.query({ tag: 'iq', attrs: { to: from, type: 'set', xmlns: 'w:profile:picture' }, content: [{ tag: 'picture', attrs: { type: 'image' }, content: img }] })
            fs.unlinkSync(media)
            reply(`Sukses set pp group.`)
          } catch {
            var data = await ronzz.updateProfilePicture(from, { url: media })
            fs.unlinkSync(media)
            reply(`Sukses set pp group.`)
          }
        } else {
          reply(`Kirim/balas gambar dengan caption ${prefix + command} untuk mengubah foto profil grup`)
        }
        break
        
      case 'backup': {
        if (!isOwner) return reply(mess.owner)
        await reply('Mengumpulkan semua file ke folder...')
        let ls = (await execSync("ls")).toString().split("\n").filter((pe) =>
          pe != "node_modules" &&
          pe != "session" &&
          pe != "package-lock.json" &&
          pe != "yarn.lock" &&
          pe != ".npm" &&
          pe != ".cache" &&
          pe != ""
        )
        if (isGroup) reply('Script akan dikirim lewat PC!')
        await execSync(`zip -r SC-AUTO-ORDER.zip ${ls.join(" ")}`)
        await ronzz.sendMessage(sender, {
          document: await fs.readFileSync("./SC-AUTO-ORDER.zip"),
          mimetype: "application/zip",
          fileName: "SC-AUTO-ORDER.zip",
          caption: "Sukses backup Script"
        }, { quoted: m })
        await execSync("rm SC-AUTO-ORDER.zip");
      }
        break

      default:
        if (budy.startsWith('=>')) {
          if (!isOwner) return
          function Return(sul) {
            sat = JSON.stringify(sul, null, 2)
            bang = util.format(sat)
            if (sat == undefined) {
              bang = util.format(sul)
            }
            return reply(bang)
          }
          try {
            reply(util.format(eval(`(async () => { ${budy.slice(3)} })()`)))
          } catch (e) {
            reply(String(e))
          }
        }
        if (budy.startsWith('>')) {
          if (!isOwner) return
          try {
            let evaled = await eval(budy.slice(2))
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
            await reply(evaled)
          } catch (err) {
            reply(String(err))
          }
        }
        if (budy.startsWith('$')) {
          if (!isOwner) return
          let qur = budy.slice(2)
          exec(qur, (err, stdout) => {
            if (err) return reply(err)
            if (stdout) {
              reply(stdout)
            }
          })
        }
    }
  } catch (err) {
    console.log(color('[ERROR]', 'red'), err)
  }
}